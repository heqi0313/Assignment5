package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * 
 * @author apple ʵ��IMailService�ӿ�
 */
public class Mail2014302580201 implements IMailService {
	private String user = "s458051000@sina.com";
	private String password = "123456qq";
	private final transient Properties props1 = System.getProperties();
	private final transient Properties props2 = System.getProperties();
	private transient Session session1;
	private transient Session session2;
	private transient MailAuthenticator2014302580201 authenticator1;
	private transient MailAuthenticator2014302580201 authenticator2;
	private Store store;

	public void connect() throws MessagingException {
		props1.put("mail.smtp.auth", "true");
		props1.put("mail.smtp.host", "smtp.sina.com");
		authenticator1 = new MailAuthenticator2014302580201(user, password);
		session1 = Session.getInstance(props1, authenticator1);
		props2.put("mail.store.protocol", "imap");
		props2.put("mail.imap.host", "imap.sina.com");
		authenticator2 = new MailAuthenticator2014302580201(user, password);
		session2 = Session.getInstance(props2, authenticator2);
		store = session2.getStore();
		store.connect();
	}

	public void send(String recipient, String subject, Object content) throws MessagingException {
		MimeMessage message = new MimeMessage(session1);
		message.setFrom(new InternetAddress(authenticator1.getUsername()));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(), "text/html;charset=utf-8");
		Transport.send(message);
	}

	public boolean listen() throws MessagingException {
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		int NewMailNumber = folder.getNewMessageCount();
		if (NewMailNumber == 0) {
			return false;
		} else {
			return true;
		}
	}

	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		Message[] message = folder.getMessages();
		int MailNumber = message.length;
		String MailString = "";
		for (int i = MailNumber; i > 0; i--) {
			if ((message[i - 1].getFrom()[0]).toString().contains("issjava2015@foxmail.com")) {
				MailString = (String) message[i - 1].getContent();
			}
		}
		folder.close(false);
		store.close();
		return MailString;
	}
}

/**
 * 
 * @author apple ��֤�˻�
 */
class MailAuthenticator2014302580201 extends Authenticator {
	private String username;
	private String password;

	/**
	 * 
	 * @param username
	 *            �û���
	 * @param password
	 *            ����
	 */
	public MailAuthenticator2014302580201(String username, String password) {
		this.username = username;
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	protected PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(username, password);
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}